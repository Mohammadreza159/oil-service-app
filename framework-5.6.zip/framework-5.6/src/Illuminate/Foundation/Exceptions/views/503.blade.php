@extends('errors::layout')

@section('title', 'Service Unavailable')

@section('message', 'Be right back.')
