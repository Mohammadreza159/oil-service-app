<?php

namespace Illuminate\Contracts\Events;

interface ShouldDispatchAfterCommit
{
    //
}
